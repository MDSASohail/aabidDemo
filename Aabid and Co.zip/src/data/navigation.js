// src/data/navigation.js

export const navigation = [
  { label: "Home", path: "/" },
  { label: "Work With Us", path: "/work-with-us" },
  { label: "About", path: "/about" },
  { label: "Partners", path: "/partners" },
  { label: "Focus Areas", path: "/focus-areas" },
  { label: "Contact", path: "/contact" },
  { label: "Clients", path: "/clients" },
];


// 
//{ label: "Insights", path: "/insights" },
