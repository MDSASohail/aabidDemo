// src/data/contactInfo.js

export const contactInfo = [
  {
    label: "Official Email",
    value: "aabidandcompany@gmail.com",
  },
  {
    label: "Location",
    value: "India",
  },
  {
    label: "Mobile Number",
    value: "+91 7870266282, +91 8092566282",
  },
  {
    label: "LinkedIn",
    value: "linkedin.com/company/aabidco",
    link: "https://linkedin.com",
  },
];
