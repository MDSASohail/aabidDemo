// src/pages/Contact/components/index.js

export { default as ContactIntroSection } from "./ContactIntroSection";
export { default as ContactInfoSection } from "./ContactInfoSection";
