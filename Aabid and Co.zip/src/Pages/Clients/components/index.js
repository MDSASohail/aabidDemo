// src/pages/Clients/components/index.js

export { default as ClientsIntroSection } from "./ClientsIntroSection";
export { default as ClientsGridSection } from "./ClientsGridSection";
