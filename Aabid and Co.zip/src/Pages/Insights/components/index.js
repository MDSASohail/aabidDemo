// src/pages/Insights/components/index.js

export { default as InsightsIntroSection } from "./InsightsIntroSection";
export { default as InsightsGridSection } from "./InsightsGridSection";
