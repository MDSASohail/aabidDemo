// src/pages/Companies/components/index.js

export { default as CompaniesIntroSection } from "./CompaniesIntroSection";
export { default as CompaniesGridSection } from "./CompaniesGridSection";
// export { default as CompanyCard } from "../../../domain/Company/CompanyCard";
// export { default as CompanyStatusBadge } from "../../../domain/Company/CompanyStatusBadge";
