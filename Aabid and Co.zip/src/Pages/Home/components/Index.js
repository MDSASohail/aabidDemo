// src/pages/Home/components/index.js

export { default as HeroSection } from "./HeroSection";
export { default as WhatWeAreSection } from "./WhatWeAreSection";
export { default as CompaniesPreviewSection } from "./CompaniesPreviewSection";
export { default as PhilosophySection } from "./PhilosophySection";
export { default as FounderNoteSection } from "./FounderNoteSection";
export { default as ClosingStatementSection } from "./ClosingStatementSection";
