// src/pages/WorkWithUs/components/index.js

export { default as WorkIntroSection } from "./WorkIntroSection";
export { default as WorkOptionsSection } from "./WorkOptionsSection";
