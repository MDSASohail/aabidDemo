// src/pages/About/components/index.js

export { default as AboutIntroSection } from "./AboutIntroSection";
export { default as WhatWeAreSection } from "./WhatWeAreSection";
export { default as WhatWeAreNotSection } from "./WhatWeAreNotSection";
export { default as VisionSection } from "./VisionSection";
export { default as OperatingModelSection } from "./OperatingModelSection";
export { default as LegalClaritySection } from "./LegalClaritySection";
