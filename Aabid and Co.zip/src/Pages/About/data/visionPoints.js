// src/pages/About/data/visionPoints.js

export const visionPoints = [
  "Build institutions that outlast individuals.",
  "Create businesses with long-term social and economic value.",
  "Develop systems that scale responsibly.",
  "Encourage independent leadership within each venture.",
];
