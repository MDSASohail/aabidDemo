// src/pages/FocusAreas/components/index.js

export { default as FocusAreasIntroSection } from "./FocusAreasIntroSection";
export { default as FocusAreasGridSection } from "./FocusAreasGridSection";
