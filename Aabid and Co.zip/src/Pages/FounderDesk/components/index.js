// src/pages/FounderDesk/components/index.js

export { default as FounderIntroSection } from "./FounderIntroSection";
export { default as FounderProfileSection } from "./FounderProfileSection";
export { default as FounderPhilosophySection } from "./FounderPhilosophySection";
export { default as FounderJourneySection } from "./FounderJourneySection";
export { default as FounderVisionSection } from "./FounderVisionSection";
