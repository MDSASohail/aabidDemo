// src/pages/FounderDesk/data/visionPoints.js

export const visionPoints = [
  "Build multi-sector institutions that create long-term value.",
  "Develop leaders and independent teams within each venture.",
  "Integrate technology, safety, media, and education into sustainable systems.",
  "Contribute to responsible business culture in India and beyond.",
];
