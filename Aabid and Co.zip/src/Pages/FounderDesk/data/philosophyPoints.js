// src/pages/FounderDesk/data/philosophyPoints.js

export const philosophyPoints = [
  "Think in decades, not quarters.",
  "Build systems before scaling businesses.",
  "Prioritise ethics and governance over shortcuts.",
  "Value learning and reflection as core assets.",
];
