export { default as Heading } from "./Heading";
