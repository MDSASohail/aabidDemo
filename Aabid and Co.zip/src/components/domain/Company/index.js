// src/components/domain/Company/index.js

export { default as CompanyCard } from "./CompanyCard";
export { default as CompanyStatusBadge } from "./CompanyStatusBadge";
