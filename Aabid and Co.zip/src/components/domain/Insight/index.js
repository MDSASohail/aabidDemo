// src/components/domain/Insight/index.js

export { default as InsightCard } from "./InsightCard";
export { default as InsightMeta } from "./InsightMeta";
