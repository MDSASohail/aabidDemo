// src/components/domain/WorkOption/index.js

export { default as WorkOptionCard } from "./WorkOptionCard";
