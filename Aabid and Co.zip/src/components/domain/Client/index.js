// src/components/domain/Client/index.js

export { default as ClientCard } from "./ClientCard";
