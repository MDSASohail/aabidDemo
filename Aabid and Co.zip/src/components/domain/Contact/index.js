// src/components/domain/Contact/index.js

export { default as ContactItem } from "./ContactItem";
