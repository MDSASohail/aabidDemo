// src/components/domain/FocusArea/index.js

export { default as FocusAreaCard } from "./FocusAreaCard";
