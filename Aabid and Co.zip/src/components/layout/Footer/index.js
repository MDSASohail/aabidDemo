// src/components/layout/Footer/index.js

export { default as Footer } from "./Footer";
