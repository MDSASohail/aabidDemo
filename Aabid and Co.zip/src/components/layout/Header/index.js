// src/components/layout/Header/index.js

export { default as Header } from "./Header";
